Rhino is a java implementation of javascript. You can download
the binaries at:
  http://www.mozilla.org/rhino/
  
For the batch-file to work, put the file "js.jar" from the 
Rhino binary package into the lib folder.